package com.example.demo;

public class Post {
    String text;
    int id;
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setPost(String text, int id){
        this.text = text;
        this.id = id;
    }
    public String getText() {
        return text;
    }


    public void setText(String text) {
        this.text = text;
    }


    public Post() {
    }
}
