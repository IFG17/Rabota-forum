package com.example.demo;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class Theme {
    private final List<Post> posts = new ArrayList<>();
    String name;

    String text; // title

    void newPost (String text, int id){
        Post post = new Post();
        post.setPost(text, id);
        posts.add(post);


    }
    void deletePost (int id){
        for (Post post: posts){
            if (post.getId() == id){
                posts.remove(post);
            }
        }
    }

    void setTheme(String name, String text){

        this.name = name;
        this.text = text;
    }
    void updateTheme (String name){
        this.name = name;
    }
    public String getName (){
        return this.name;
    }


    public Theme() {
    }

    public Theme(String name, String text) {
        this.name = name;
        this.text = text;
    }

    public List<Post> getPosts() {
        return posts;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
