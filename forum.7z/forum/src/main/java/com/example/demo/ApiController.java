package com.example.demo;

import jdk.jshell.Snippet;
import org.apache.logging.log4j.status.StatusConsoleListener;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ThemeResolver;
import org.springframework.web.servlet.tags.ThemeTag;

import java.util.ArrayList;
import java.util.List;

@Controller
@RestController
public class ApiController {


    private List<Theme> themes = new ArrayList<>();

    //curl -XPOST http://localhost:8080/themes/Teorii_zagovora -d masson
    @PostMapping("themes/{name}")
    public ResponseEntity<Void> setTheme(@PathVariable ("name") String name, @RequestBody String text){

        for (Theme theme: themes){
            System.out.println(theme.getName());
            if (theme.getName().equals(name)){

                System.out.println ("Theme is already done");
                return ResponseEntity.status(409).build();
            }
        }
        Theme theme = new Theme();
        theme.setTheme(name, text);
        themes.add(theme);
        System.out.println ("Theme created" + " " + name + " [" + text + "]");
        return ResponseEntity.accepted().build();
    }
    //curl -XGET http://localhost:8080/themes
    @GetMapping ("themes")
    public ResponseEntity<List<Theme>> getThemes (){
        System.out.println("___________________Theme list ______________________");
        for (Theme theme: themes){
            System.out.println(theme.getName());

        }
        return ResponseEntity.ok(themes);

    }
    //curl -XDELETE http://localhost:8080/themes/delete/Teorii_zagovora
    @DeleteMapping ("themes/delete/{name}")
    public ResponseEntity<Snippet.Status> deleteTheme (@PathVariable String name){
        for (Theme theme: themes){
            if (theme.getName().equals(name)){
                themes.remove(theme);
                System.out.println(theme.getName() + "deleted");
                return ResponseEntity.accepted().build();
            }

        }
        System.out.println("This theme doesn't exist");
        return ResponseEntity.status(409).build();
    }
    //curl -XPUT http://localhost:8080/themes/update/Teorii_zagovora/Plohie_gipotezi
    @PutMapping ("themes/update/{name}/{newname}")
    public ResponseEntity<Snippet.Status> updateTheme (@PathVariable ("name") String name, @PathVariable ("newname") String newname){
        for (Theme theme: themes){
            if (theme.getName().equals(name)){

                System.out.println(theme.getName() + "updated");
                theme.setName(newname);
                return ResponseEntity.accepted().build();
            }

        }
        System.out.println("This theme doesn't exist");
        return ResponseEntity.status(409).build();
    }
    //curl -XGET http://localhost:8080/themes/count
    @GetMapping ("themes/count")
    public ResponseEntity<Integer> countThemes (){
        return ResponseEntity.ok(themes.size());
    }
    //curl -XDELETE http://localhost:8080/themes/deleteall
    @DeleteMapping ("themes/deleteall")
    public ResponseEntity<Void> deleteThemes (){
        themes = new ArrayList<Theme>();
        return ResponseEntity.accepted().build();

    }
    //curl -XGET http://localhost:8080/themes/Teorii_zagovora
    @GetMapping ("themes/{name}")
    public ResponseEntity<Theme> getTheme (@PathVariable ("name") String name){
        for (Theme theme: themes){
            if (theme.getName().equals(name)){
                return ResponseEntity.ok(theme);
            }
        }
        return ResponseEntity.status(409).build();
    }
    //curl -XPOST http://localhost:8080/themes/Teorii_zagovora/privet/666
    @PostMapping("themes/{name}/{posttext}/{id}")
    public ResponseEntity<Snippet.Status> setPost (@PathVariable ("name") String name, @PathVariable ("posttext") String text, @PathVariable ("id") Integer id){
        for (Theme theme: themes){
            if (theme.getName().equals(name)){
                theme.newPost(text, id);
            }
        }
        return ResponseEntity.status(409).build();
    }
    //curl -XDELETE http://localhost:8080/themes/Teorii_zagovora/delete/666
    @DeleteMapping("themes/{name}/delete/{id}")
    public ResponseEntity<Snippet.Status> deletePost (@PathVariable ("name") String name, @PathVariable ("id") Integer id){
        for (Theme theme: themes){
            if (theme.getName().equals(name)){
                theme.deletePost(id);
            }
        }
        return ResponseEntity.status(409).build();
    }

    //curl -XPOST http://localhost:8080/users/create/Vasya/239/02390/5
//    @PostMapping("users/create/{username}/{id}/{password}/{age}")
//    public ResponseEntity<Void> addUser(@PathVariable("username") String username, @PathVariable("id") Integer id, @PathVariable("password") String password, @PathVariable("age") Integer age) {
//        boolean flag = true;
//        for (User user: users){
//            if (user.getId() == id){
//                flag = false;
//            }
//        }
//        if (!flag){
//            User user = new User();
//            user.setUser(id,age,password,username);
//
//            return ResponseEntity.accepted().build();
//        }
//        return ResponseEntity.status(409).build();
//    }
//    //curl -XGET http://localhost:8080/users/get/239
//    @GetMapping("users/get/")
//    public ResponseEntity<String> getUser(@PathVariable("id") Integer id) {
//        for (User user: users){
//            if (user.getId() == id){
//                return ResponseEntity.ok("ad");
//
//            }
//        }
//
//        return ResponseEntity.status(404).build();
//    }
//    //curl -XDELETE http://localhost:8080/users/delete/239
//    @DeleteMapping ("users/delete/{id}")
//    public ResponseEntity<Void> deleteUser(@PathVariable("id") Integer id) {
//
//        for (User user: users){
//            if (user.getId() == id){
//                users.remove(user);
//            }
//        }
//
//        return ResponseEntity.status(404).build();
//    }
//    //curl -XDELETE http://localhost:8080/users/setusername/239/Vasytka
//    @PutMapping ("users/setusername/{id}/{username}")
//    public ResponseEntity<Void> setUsername(@PathVariable("id") Integer id, @PathVariable("username") String name) {
//
//        for (User user: users){
//            if (user.getId() == id){
//                user.setUsername(name);
//            }
//        }
//
//        return ResponseEntity.status(404).build();
//    }



}
